// Simulated in-memory database
const appData = {
    users: [], // { id, email, password, role, name }
    tasks: [], // { id, title, project, description, priority, status, assignee, dueDate }
    agendaItems: [], // { id, title, date }
    teamMembers: [], // { id, email, role }
    projectStatus: "", // "On Track", "At Risk", "Off Track"
    files: [], // { id, name, size, uploader }
    comments: [], // { id, taskId, text, author }
    analyticsReports: [], // { id, title, content }
};

// Save data to localStorage
function saveData() {
    localStorage.setItem('appData', JSON.stringify(appData));
}

// Load data from localStorage
function loadData() {
    const storedData = localStorage.getItem('appData');
    if (storedData) {
        Object.assign(appData, JSON.parse(storedData));
    }
}

// Initialize data on page load
document.addEventListener('DOMContentLoaded', loadData);