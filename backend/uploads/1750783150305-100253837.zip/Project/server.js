const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const session = require('express-session');
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;

const port = 3000;
const app = express();

// Dummy user for traditional login
const users = [
  {
    email: 'admin@example.com',
    password: '123456',
    name: 'Admin User',
    role: 'Admin'
  }
];

// Session setup
app.use(session({
  secret: 'secret',
  resave: false,
  saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session());

// Body parser and static files
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Serialize and deserialize user for session
passport.serializeUser((user, done) => {
  done(null, user);
});
passport.deserializeUser((obj, done) => {
  done(null, obj);
});

// ✅ Google OAuth Strategy
const GOOGLE_CLIENT_ID = '672159425581-bldvjkf8k49hl05ssd9bucs0prequu6i.apps.googleusercontent.com';
const GOOGLE_CLIENT_SECRET = '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';

passport.use(new GoogleStrategy({
  clientID: GOOGLE_CLIENT_ID,
  clientSecret: GOOGLE_CLIENT_SECRET,
  callbackURL: '/auth/google/callback'
}, (accessToken, refreshToken, profile, done) => {
  // You can save profile to DB if needed
  return done(null, profile);
}));

// ✅ Google Auth Routes
app.get('/auth/google',
  passport.authenticate('google', { scope: ['profile', 'email'] })
);

app.get('/auth/google/callback',
  passport.authenticate('google', { failureRedirect: '/' }),
  (req, res) => {
    res.redirect('/overview.html');
  }
);

// 🧠 POST login route (existing functionality)
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  const user = users.find(u => u.email === email && u.password === password);

  if (user) {
    return res.status(200).json({ message: 'Login successful' });
  } else {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
});
app.post('/signup', (req, res) => {
  const { name, email, password } = req.body;

  const existingUser = users.find(u => u.email === email);
  if (existingUser) {
    return res.status(400).json({ message: 'Email already exists' });
  }

  users.push({ name, email, password, role: 'User' });
  return res.status(200).json({ message: 'Signup successful' });
});
// Forgot password
app.post('/forgot', (req, res) => {
  const { email } = req.body;
  const user = users.find(u => u.email === email);

  if (!user) {
    return res.status(404).json({ message: 'Email not found' });
  }

  // Normally you'd send email with reset link/token
  return res.status(200).json({ message: 'Password reset link sent (not really, this is a demo)' });
});

// Serve the overview page
app.get('/overview.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'overview.html'));
});

// Placeholder for Microsoft and Apple (to implement later)
app.get('/auth/apple', (req, res) => {
  res.send('Apple login not yet implemented. You’ll redirect here.');
});

app.get('/auth/microsoft', (req, res) => {
  res.send('Microsoft login not yet implemented. You’ll redirect here.');
});

// Server Start
app.listen(port, () => {
  console.log(`✅ Server running at http://localhost:${port}`);
});
